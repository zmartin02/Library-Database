package com.project.Zach_m.controller;


import com.project.Zach_m.entity.Book;
import com.project.Zach_m.entity.User;
import com.project.Zach_m.repository.BookRepository;
import com.project.Zach_m.repository.UserRepository;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/book")
public class BorrowingController {

    private UserRepository userRepository;

    private BookRepository bookRepository;

    public BorrowingController(UserRepository userRepository,
                               BookRepository bookRepository){
        this.userRepository = userRepository;
        this.bookRepository = bookRepository;
    }

    @PostMapping
    public User saveUserWithBook(@RequestBody User user){
        return userRepository.save(user);
    }

    @GetMapping
    public List<User> findAllUsers(){
        return userRepository.findAll();
    }

    @GetMapping("/userId")
    public User findUser(String userId){
        return userRepository.findById(userId).orElse(null);
    }

    @GetMapping("/find/{name}")
    public List<User> findUsersContainingByName(@PathVariable String name){
        return userRepository.findByNameContaining(name);

    }

    @GetMapping("/search/{title}")
    public List<Book> findBoolByTitleContaining(@PathVariable String title){
        return bookRepository.findByTitleContaining(title);
    }
}
