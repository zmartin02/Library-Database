package com.project.Zach_m.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Entity
@Table(name = "USER_TBL")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    private String name;
    @GeneratedValue
    private Integer id;
    private Integer age;
    private String address;

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(name = "BORROWED_BOOKS_TBL",
    joinColumns = {
            @JoinColumn(name = "user_name", referencedColumnName = "name")
    },
    inverseJoinColumns = {
            @JoinColumn(name = "book_title", referencedColumnName = "title")
    })
    @JsonManagedReference
    private Set<Book> books;
}
