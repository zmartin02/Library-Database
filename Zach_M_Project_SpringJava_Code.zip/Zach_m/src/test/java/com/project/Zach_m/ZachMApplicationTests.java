package com.project.Zach_m;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZachMApplicationTests {

	@Test
	void contextLoads() {
	}

}
